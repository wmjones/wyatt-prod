import json
import os
from todoist_api_python.api import TodoistAPI
import boto3

def lambda_handler(event, context):
    todoist_api_key = os.environ["TODOIST_API_KEY"]
    s3_bucket_name = os.environ["S3_BUCKET_NAME"]

    api = TodoistAPI(todoist_api_key)
    api.sync()

    incomplete_tasks = api.items.all(filter="status:incomplete")

    s3 = boto3.client("s3")
    s3.put_object(
        Bucket=s3_bucket_name, Key="data/incomplete_tasks.json", Body=json.dumps(incomplete_tasks), ContentType="application/json"
    )

    return {"statusCode": 200, "body": json.dumps("Data saved to S3")}
